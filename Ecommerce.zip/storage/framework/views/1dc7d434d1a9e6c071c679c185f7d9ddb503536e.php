<?php $__env->startSection('content'); ?>
<section id="cart-page">
        <div class="container">
            <!-- ========================================= CONTENT ========================================= -->
            <div class="col-xs-12 col-md-9 items-holder no-margin">
                <?php if(!empty($products)): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="row no-margin cart-item">
                    <div class="col-xs-12 col-sm-2 no-margin">
                        <a href="<?php echo e(route('product',['id' => $p->product_id])); ?>" class="thumb-holder">
                            <img class="lazy" alt="" src="<?php echo e($p->product_image); ?>" />
                        </a>
                    </div>

                    <div class="col-xs-12 col-sm-5 ">
                        <div class="title">
                            <a href="<?php echo e(route('product',['id' => $p->product_id])); ?>"><?php echo e($p->product_name); ?></a>
                        </div>
                        
                    </div>

                    <div class="col-xs-12 col-sm-3 no-margin">
                        <div class="quantity">
                            <div class="le-quantity">
                                <form>
                                    <a class="" href="#reduce"></a>
                                    <input name="quantity" readonly="readonly" type="text" value="<?php echo e($p->quantity_ordered); ?>*$<?php echo e($p->product_price); ?>" />
                                    <a class="" href="#add"></a>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-2 no-margin">
                        <div class="price">
                            $<?php echo e($p->product_price * $p->quantity_ordered); ?>

                        </div>
                        <?php if($p->is_paid == 0): ?>
                        <a class="close-btn" href="<?php echo e(route('deleteproductsavedincart',['id' => $p->order_id])); ?>"></a>
                        <?php endif; ?>
                    </div>
                </div><!-- /.cart-item -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <!-- ========================================= CONTENT : END ========================================= -->

            <!-- ========================================= SIDEBAR ========================================= -->
<?php if($checkout->is_paid == 0): ?>
            <div class="col-xs-12 col-md-3 no-margin sidebar ">
                <div class="widget cart-summary">
                    <h1 class="border">shopping cart</h1>
                    <div class="body">
                        <ul class="tabled-data no-border inverse-bold">
                            <li>
                                <label>cart subtotal</label>
                                <div class="value pull-right">$<?php echo e($checkout->total_price); ?></div>
                            </li>
                       <!--     <li>
                                <label>shipping</label>
                                <div class="value pull-right">free shipping</div>
                            </li> -->
                        </ul>
                        <ul id="total-price" class="tabled-data inverse-bold no-border">
                            <li>
                                <label>order total</label>
                                <div class="value pull-right">$<?php echo e($checkout->total_price); ?></div>
                            </li>
                        </ul>
                        <div class="buttons-holder">
                            <a class="le-button big" href="<?php echo e(route('scheckout',['id' => $checkout->id])); ?>" >Place order</a>
                            <a class="simple-link block" href="<?php echo e(route('deletesavedcheckout',['id' => $checkout->id])); ?>" >Delete Checkout</a>
                        </div>
                    </div>
                </div><!-- /.widget -->

            </div><!-- /.sidebar -->
            <?php endif; ?>
            <?php else: ?>
            <h1>You have not added any product to the cart</h1>
            <?php endif; ?>

            <!-- ========================================= SIDEBAR : END ========================================= -->
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.MasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/Frontend/dbsavedcart.blade.php ENDPATH**/ ?>