
<?php echo $__env->make('Frontend.includes.topnavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row" style="margin:8px;">
    <div class="container-fluid">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <?php if(Session('error')): ?>
                <div class="alert alert-danger" role="alert">
                     <?php echo e(Session('error')); ?>

                      </div>
                      <?php endif; ?>

                      <?php if(Session('success')): ?>
                      <div class="alert alert-success" role="alert">
                            <?php echo e(Session('success')); ?>

                          </div>
                      <?php endif; ?>

                      <?php if(Session('info')): ?>
                      <div class="alert alert-info" role="alert">
                            <?php echo e(Session('info')); ?>

                          </div>
                      <?php endif; ?>
        </div>
    </div>
</div>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('Frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/Frontend/MasterLayout.blade.php ENDPATH**/ ?>