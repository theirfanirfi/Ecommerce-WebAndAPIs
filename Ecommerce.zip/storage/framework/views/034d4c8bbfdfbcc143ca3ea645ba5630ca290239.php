 <?php if(!empty($rvs)): ?>
 <?php if($rvs->count() > 0): ?>
 <!-- ========================================= RECENTLY VIEWED ========================================= -->
            <section id="recently-reviewd" class="wow fadeInUp">
                <div class="container">
                    <div class="carousel-holder hover">

                        <div class="title-nav">
                            <h2 class="h1">Recently Viewed</h2>
                            <div class="nav-holder">
                                <a href="#prev" data-target="#owl-recently-viewed" class="slider-prev btn-prev fa fa-angle-left"></a>
                                <a href="#next" data-target="#owl-recently-viewed" class="slider-next btn-next fa fa-angle-right"></a>
                            </div>
                        </div><!-- /.title-nav -->

                        <div id="owl-recently-viewed" class="owl-carousel product-grid-holder">

                            <?php $__currentLoopData = $rvs->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="no-margin carousel-item product-item-holder size-small hover">
                                <div class="product-item">
                                    <div class="ribbon red"><span>sale</span></div>
                                    <div class="image">
                                        <img alt="" src="<?php echo e($r->product_image); ?>" data-echo="<?php echo e($r->product_image); ?>" />
                                    </div>
                                    <div class="body">
                                        <div class="title">
                                            <a href="single-product.html"><?php echo e($r->product_name); ?></a>
                                        </div>
                                        <div class="brand"><?php echo e($r->cat_title); ?></div>
                                    </div>
                                    <div class="prices">
                                        <div class="price-current text-right"><?php echo e($r->product_price); ?></div>
                                    </div>
                                    <div class="hover-area">
                                        <div class="add-cart-button">
                                            <a href="<?php echo e(route('addtocart',['id' => $r->product_id])); ?>" class="le-button">Add to Cart</a>
                                        </div>
                                        <div class="wish-compare">
                                            <a class="btn-add-to-wishlist" href="<?php echo e(route('addtowhishlist',['id' => $r->product_id])); ?>">Add to Wishlist</a>
                                        </div>
                                    </div>
                                </div><!-- /.product-item -->
                            </div><!-- /.product-item-holder -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div><!-- /#recently-carousel -->

                    </div><!-- /.carousel-holder -->
                </div><!-- /.container -->
            </section><!-- /#recently-reviewd -->
            <!-- ========================================= RECENTLY VIEWED : END ========================================= -->
<?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/Frontend/includes/recentlyviewed.blade.php ENDPATH**/ ?>