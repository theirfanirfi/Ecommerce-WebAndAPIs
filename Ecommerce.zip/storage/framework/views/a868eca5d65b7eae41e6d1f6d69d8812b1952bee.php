<?php $__env->startSection('content'); ?>

<div class="main-content" id="main-content">
        <div class="row">
            <div class="col-lg-10 center-block page-wishlist style-cart-page inner-bottom-xs">

                <div class="inner-xs">
                    <div class="page-header">
                        <h2 class="page-title">My Wishlist</h2>
                    </div>
                </div><!-- /.section-page-title -->
                <?php if($wl->count() > 0): ?>
                <div class="items-holder">
                    <div class="container-fluid wishlist_table">

                        <?php $__currentLoopData = $wl->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row cart-item cart_item" id="yith-wcwl-row-1">

                            <div class="col-xs-12 col-sm-1 no-margin">
                                <a title="Remove this product" class="remove_from_wishlist remove-item" href="<?php echo e(route('removefromwishlist',['id' => $w->id])); ?>">×</a>
                            </div>

                            <div class="col-xs-12 col-sm-1 no-margin">
                                <a href="single-product.html">
                                    <img width="73" height="73" alt="Canon PowerShot Elph 115 IS" class="attachment-shop_thumbnail wp-post-image" src="<?php echo e($w->product_image); ?>">
                                </a>
                            </div>
                            <div class="col-xs-12 col-sm-4 no-margin">
                                <div class="title">
                                    <a href="<?php echo e(route('product',['id' => $w->product_id])); ?>"><?php echo e($w->product_name); ?></a>
                                </div><!-- /.title -->
                                <div>
                                    <?php if($w->quantity == $w->sold): ?>
                                    <span class="label label-danger wishlist-out-of-stock">Out of Stock</span>
                                    <?php else: ?>
                                    <span class="label label-success wishlist-in-stock">In Stock</span>
                                    <?php endif; ?>

                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-3 no-margin">
                                <div class="price">
                                    <span class="amount">$<?php echo e($w->product_price); ?></span>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-3 no-margin">
                                <div class="text-right">
                                    <div class="add-cart-button">
                                            <?php if($w->quantity > $w->sold): ?>
                                    <a class="le-button add_to_cart_button product_type_simple" href="<?php echo e(route('addtocart',['id' => $w->product_id])); ?>">Add to cart</a>
                                            <?php else: ?>
                                            <a class="le-button disabled product_type_simple" href="">Add to cart</a>

                                            <?php endif; ?>

                                    </div>
                                </div>
                            </div>

                        </div><!-- /.cart-item -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div><!-- /.wishlist-table -->
                </div><!-- /.items-holder -->

                <?php else: ?>
                <h1>Your WishList is empty.</h1>
                <?php endif; ?>
            </div><!-- .large-->
        </div><!-- .row-->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.MasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/Frontend/wishlist.blade.php ENDPATH**/ ?>