<?php $__env->startSection('content'); ?>
<div id="products-tab" class="wow fadeInUp">
        <div class="container">
            <div class="tab-holder">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" >
                    <li class="active"><a href="#featured" data-toggle="tab">My Account</a></li>
                    <li><a href="#new-arrivals" data-toggle="tab">Paid Checkouts</a></li>
                    <li><a href="#unpaid" data-toggle="tab">UnPaid Checkouts</a></li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="featured">
                        <div class="product-grid-holder">
                            <div class="row" style="margin:20px;">
                                <div class="col-md-6">
                                        <form action="<?php echo e(route('updateaccount')); ?>" method="POST">
                                            <p>
                                            <label>Full name: </label>
                                                <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" />
                                            </p>
                                            <?php echo csrf_field(); ?>
                                            <p>
                                                    <label>Email: </label>
                                                        <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control" />
                                                    </p>




                                        <button type="submit" class="btn btn-primary">Update Account</button>
                                        </form>
                                </div>

                                <div class="col-md-6">
                                    <form action="<?php echo e(route('changepassword')); ?>" method="POST">
                                    <p>
                                        <?php echo csrf_field(); ?>
                                                <label>Current Password: </label>
                                                    <input type="password" name="current_pass" class="form-control" />

                                                    <label>New Password: </label>
                                                    <input type="password" name="new_pass" class="form-control" />
                                                </p>

                                                <button type="submit" class="btn btn-primary">Change Password</button>
                                    </form>

                                </div>
                            </div>


                        </div>


                    </div>


                    <div class="tab-pane" id="new-arrivals">
                        <div class="product-grid-holder">
            <!-- ========================================= CONTENT ========================================= -->
            <div class="col-xs-12 col-md-9 items-holder no-margin">
                    <?php if(!empty($paid)): ?>
                    <table class="table table-responsive" style="margin:20px;">

                        <th>Products</th>
                        <th>Created on</th>
                        <th>Total Price</th>
                        
                    <?php $__currentLoopData = $paid->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td> <?php echo e($p->products_quantity); ?> | <a href="<?php echo e(route('savedcart',['id' => $p->id])); ?>">View</a></td>
                            <td><?php echo e($p->created_at); ?></td>
                            <td>$<?php echo e($p->total_price); ?></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>

                    <?php endif; ?>

                </div>
                <!-- ========================================= CONTENT : END ========================================= -->

                        </div>


                    </div>


                    <div class="tab-pane" id="unpaid">
                            <div class="product-grid-holder">
                                    <?php if(!empty($unpaid)): ?>
                                    <table class="table table-responsive" style="margin:20px;">

                                        <th>Products</th>
                                        <th>Created on</th>
                                        <th>Total Price</th>
                                        <th>Checkout</th>
                                        <th>Delete</th>
                                    <?php $__currentLoopData = $unpaid->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($p->products_quantity); ?> | <a href="<?php echo e(route('savedcart',['id' => $p->id])); ?>">View</a></td>
                                            <td><?php echo e($p->created_at); ?></td>
                                            <td>$<?php echo e($p->total_price); ?></td>
                                            <td>$<?php echo e($p->total_price); ?></td>
                                            <td><a href="<?php echo e(route('deletesavedcheckout',['id' => $p->id])); ?>">Delete</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </table>

                                    <?php endif; ?>

                            </div>


                        </div>

                </div>
            </div>
        </div>
    </div>


<?php echo $__env->make('Frontend.includes.recentlyviewed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.MasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/Frontend/myaccount.blade.php ENDPATH**/ ?>