<h1>working</h1>
<?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/Mail/ordershipped.blade.php ENDPATH**/ ?>