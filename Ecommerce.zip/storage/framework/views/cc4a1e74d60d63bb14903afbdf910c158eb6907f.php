<?php $__env->startSection('content'); ?>
<div id="single-product">
        <div class="container">

            <div class="no-margin col-xs-12 col-sm-6 col-md-5 gallery-holder">
                <div class="product-item-holder size-big single-product-gallery small-gallery">

                    <div id="owl-single-product" class="owl-carousel">
                        <div class="single-product-gallery-item" id="slide1">
                            <a data-rel="prettyphoto" href="<?php echo e($product->product_image); ?>">
                                <img class="img-responsive" alt="" src="<?php echo e($product->product_image); ?>" data-echo="<?php echo e($product->product_image); ?>" />
                            </a>
                        </div><!-- /.single-product-gallery-item -->

                    </div><!-- /.single-product-slider -->


                </div><!-- /.single-product-gallery -->
            </div><!-- /.gallery-holder -->


            <div class="no-margin col-xs-12 col-sm-7 body-holder">
                <div class="body">
                    <div class="availability"><label>Availability:</label><span class="available">  in stock</span></div>

                    <div class="title"><a href="#"><?php echo e($product->product_name); ?></a></div>
                    <div class="brand">sony</div>


                    <div class="buttons-holder">
                        <a class="btn-add-to-wishlist" href="<?php echo e(route('addtowishlist',['id' => $product->product_id])); ?>">add to wishlist</a>
                    </div>

                    <div class="excerpt">
                    </div>

                    <div class="prices">
                        <div class="price-current">$<?php echo e($product->product_price); ?></div>
                     <!--   <div class="price-prev">Stock: <?php echo e($product->available); ?></div> -->
                    </div>

                    <div class="qnt-holder">
                        <div class="le-quantity">
                            <form action="<?php echo e(route('addtocartproduct')); ?>" method="post">

                                <a class="minus" href="#reduce"></a>
                                <input name="quantity" readonly="readonly" type="text" value="1" />
                                <a class="plus" href="#add"></a>
                        </div>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->product_id); ?>" />
                        <button type="submit" id="addto-cart" href="<?php echo e(route('addtocart',['id' => $product->product_id])); ?>" class="le-button huge">add to cart</button>
                    </form>

                    </div><!-- /.qnt-holder -->
                </div><!-- /.body -->

            </div><!-- /.body-holder -->
        </div><!-- /.container -->
    </div><!-- /.single-product -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.MasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ecommerce\resources\views/Frontend/singleproduct.blade.php ENDPATH**/ ?>